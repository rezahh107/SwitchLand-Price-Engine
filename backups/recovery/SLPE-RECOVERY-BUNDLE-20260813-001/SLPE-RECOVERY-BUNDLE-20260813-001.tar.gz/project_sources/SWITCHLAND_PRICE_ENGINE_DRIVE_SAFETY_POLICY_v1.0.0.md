# SwitchLand Price Engine — Drive Safety Policy

policy_id: `SLPE-DRIVE-SAFETY-POLICY-001`  
version: `1.0.0`  
package_scope: `SwitchLand_Price_Engine_GPT_Project_Package_v2.0.1+`  
status: `ACTIVE_PACKAGE_SAFETY_AUTHORITY`  
runtime_class: `RUNTIME_SOURCE / ALWAYS_REQUIRED_SAFETY_DETAIL`  
instruction_activation_ref: `Drive Safety — always required`  

## 1. Scope and non-business boundary
This policy governs Google Drive external effects, historical preservation, recovery and mutation authorization. It does **not** change Master/Rulebook pricing, matching, availability, discount, Part Number, SKU, State or Promotion business semantics. When a business workflow authorizes an effect, this policy still controls whether/how a Drive mutation may be invoked.

## 2. Globally forbidden destructive actions
The Project MUST NOT invoke or request automated execution of:

- `delete`
- `permanent_delete`
- `trash`
- `empty_trash`
- destructive cleanup/purge
- automatic duplicate removal/merge when it removes or overwrites an existing Drive object

These actions are non-authorizable inside this package. An ad-hoc Owner confirmation does not override this prohibition. A future policy/package revision is required to change it.

The Project also MUST NOT claim deletion is technically impossible unless the destructive capability has actually been removed/disabled or is enforced by an external approval controller.

## 3. APPEND_ONLY protected classes
The following are `APPEND_ONLY` once historical/committed:

- historical Run records and Run artifacts;
- Authority artifacts/versions;
- Owner/User Decision records;
- Incident and recovery records;
- committed Product Pricing State / committed selector lineage and their historical predecessors.

For these classes, do not update, delete, trash, move, rename, replace or reuse the historical object. Create a successor/new record with explicit lineage and preserve the predecessor. Current selectors may point to a newly committed successor only through governed workflow; predecessor selectors/states remain historical evidence.

This policy does not grant permission to mutate Current Master. Existing Rulebook/Promotion authorization plus the Owner Confirmation Gate remain required where a non-destructive Current Master effect is otherwise permitted.

## 4. Exact Owner Confirmation Gate
Every consequential **allowed** Drive mutation requires a fresh exact Owner confirmation immediately before invocation. Present the exact pending binding and require the user to confirm the same values:

`CONFIRM_DRIVE_MUTATION | action=<ACTION> | resource_id=<RESOURCE_ID|NEW_RESOURCE> | expected_parent=<PARENT_ID> | expected_hash_or_revision=<HASH_OR_REVISION>`

Required semantics:

- `action`: exact planned non-destructive mutation/action;
- `resource_id`: exact existing Drive ID; for create use literal `NEW_RESOURCE` and also state the exact planned filename/object identity;
- `expected_parent`: exact parent Resource ID;
- `expected_hash_or_revision`: current expected hash/revision for existing target, or planned content hash for a new object when bytes exist;
- approval binds only this action/target/parent/pre-state;
- target, parent, hash, revision, candidate content or action change invalidates prior approval;
- capability + target + parameters must be revalidated before invocation;
- material write success requires persisted read-back and resulting identity/hash/revision when available.

Generic phrases such as “continue”, earlier approval, approval of a draft, or model restatement are not this gate.

## 5. Duplicate / obsolete artifact policy
Duplicate, stale-looking or obsolete-looking objects are **REPORT_ONLY**. The Project may read/list/compare and report:

- Resource IDs;
- parents;
- hashes/revisions when available;
- authority roles;
- ambiguity/conflict.

It must not auto-delete, trash, move, rename, merge, overwrite or “clean up” duplicates. If duplicates create current-authority ambiguity, block the affected decision and ask the Owner for the smallest authority-selection decision. Cleanup remains outside this package unless a future version defines a non-destructive governed procedure.

## 6. RECOVERY_BASELINE contract
Recovery uses three independent layers:

1. **Google Drive = operational SSOT.** Live current authority requires actual Drive resolution/read and applicable current selectors.
2. **GPT Project Sources = secondary readable recovery checkpoint.** `SWITCHLAND_PRICE_ENGINE_RECOVERY_CHECKPOINT_v1.0.0.json` is historical recovery metadata only; it is not current operational authority and cannot silently override Drive.
3. **Independent full backup = separate private repository or read-only storage.** It must preserve the complete recoverable bytes/history needed for disaster recovery and remain independent of the operational Drive workspace and Project package.

The independent backup is an installation prerequisite. Until its existence, location, integrity and readability are actually verified, its state is `NOT_PROVEN`.

## 7. Bounded `RECOVERY_REBASELINE` control route
This is a recovery/control route, **not a fourth normal business route**. Activate only on explicit recovery/rebaseline intent after evidence/object loss or unrecoverable lineage break.

Flow:

1. stop affected consequential workflows;
2. identify missing/deleted historical identities without inventing their content or existence;
3. read all reachable live authorities by stable IDs;
4. read the Project recovery checkpoint as historical reference, never as current SSOT;
5. inspect independent backup evidence when available;
6. create a new Incident/recovery candidate and new baseline lineage with new identities;
7. validate evidence bindings, no self-certification, parent/concurrency state and business-rule compatibility;
8. obtain the Exact Owner Confirmation Gate for every allowed Drive write;
9. create only new append-only recovery/baseline/successor artifacts; require persisted read-back;
10. report `REBASELINED_WITH_NEW_LINEAGE` only after the new lineage is actually committed and read back.

Never restore/recreate/fabricate a deleted historical Resource ID or claim `RESTORED` merely because equivalent content was reconstructed. If an external administrator independently restores an original provider object, treat that as external evidence and revalidate identity before use.

## 8. Enforcement honesty
Enforcement class at package level is primarily `JUDGMENT_ONLY / PROMPT_LEVEL_CONTRACT` plus observable tool/read-back checks. Structural archive checks can prove package contents only. Machine-enforced deletion prevention exists only when connector/app permissions actually remove destructive capabilities or an external controller rejects them.

Installation must disable destructive Drive capabilities where the platform exposes a verified granular permission/control. If that cannot be verified, label machine protection `NOT_PROVEN`; the prompt-level prohibition remains mandatory and every allowed Drive mutation still requires exact Owner confirmation.
